fx_version 'cerulean'
game 'gta5'

author 'Lowkey'
description 'Custom Territory and Store Zones'
version '1.0.0'

-- It's vital that the config loads first!
client_scripts {
    'config.lua',
    'client.lua'
}

-- If you ever decide to add server-side logic (like notifications), 
-- you'd add 'server.lua' here.