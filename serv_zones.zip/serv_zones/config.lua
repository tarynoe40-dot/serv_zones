Config = {}

Config.Zones = {
    { name = "Ballas Territory", coords = vector3(-64.34, -1577.41, 30.27), radius = 250.0, color = 27 }, -- Purple
    { name = "Vagos Territory",  coords = vector3(442.74, -2019.77, 23.47), radius = 200.0, color = 46 }, -- Yellow/Gold
    { name = "Triads Territory",     coords = vector3(-1008.37, -1124.08, 2.18), radius = 250.0,  color = 2 },  -- Green
}