Citizen.CreateThread(function()
    for _, zone in pairs(Config.Zones) do
        local blip = AddBlipForRadius(zone.coords.x, zone.coords.y, zone.coords.z, zone.radius)
        
        SetBlipColour(blip, zone.color)
        SetBlipAlpha(blip, 128) -- 128 is 50% transparency; 255 is solid.
        
        -- Optional: Add a center icon blip so players can see the name
        local iconBlip = AddBlipForCoord(zone.coords.x, zone.coords.y, zone.coords.z)
        SetBlipSprite(iconBlip, 1) -- Standard square/circle icon
        SetBlipColour(iconBlip, zone.color)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(zone.name)
        EndTextCommandSetBlipName(iconBlip)
    end
end)